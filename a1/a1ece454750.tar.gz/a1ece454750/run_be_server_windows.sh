#!/usr/bin/env bash

java -cp "dist/lib/ece454750s15a1.jar;lib/*" ece454750s15a1.BEServer $*
