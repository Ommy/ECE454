package clients;

import utilities.ServerDescriptionParser;

public class BaseClient {
    protected static final ServerDescriptionParser parser = new ServerDescriptionParser();
}
